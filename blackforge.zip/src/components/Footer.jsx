export default function Footer() {
  return (
    <footer className="py-10 text-center opacity-50">
      © 2025 BLACKFORGE — Forged by Degens
    </footer>
  );
}
