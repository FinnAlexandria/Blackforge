export const metadata={title:'Blackforge',description:'Meme chaos begins'};
export default function RootLayout({children}){return(<html lang='en'><body className='bg-black text-white font-sans'>{children}</body></html>)}
