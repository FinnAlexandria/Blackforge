export default function Footer(){
  return(
    <footer className='py-10 text-center opacity-60 text-sm'>
      © 2025 BLACKFORGE — Chaos is our utility.
    </footer>
  );
}
